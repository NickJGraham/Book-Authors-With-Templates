from django.shortcuts import render, redirect
from .models import Book, Author

#Books

def index(request):
    print("*"*100)
    print("This is the index rendering")
    context = {
        'Book' : Book.objects.all()
    }
    return render(request, "index.html", context)


def add_book(request):
    print("Adding New Book")
    new_book = Book.objects.create(title=request.POST['title'], desc=request.POST['desc'])
    return redirect('/')

def book_info(request, id):
    print("This is the Book Info Page Hopefully")
    context = {
        'book': Book.objects.get(id = id),
        'authors': Book.objects.get(id = id).written_by.all(),
        'all_authors': Author.objects.all(),
    }
    return render(request, "book_info.html", context)

def append_authors(request, id):
    option = Author.objects.get(id = request.POST['select_author'])
    Book.objects.get(id = id).written_by.add(option)
    return redirect(f'/book_info/{id}')

#Authors

def authors(request):
    context = {
        'Author': Author.objects.all()
    }
    return render(request, "author.html", context)

def add_author(request):
    print('Adding New Author')
    new_author = Author.objects.create(firstname = request.POST['firstname'], lastname = request.POST['lastname'], notes = request.POST['notes'])
    return redirect('/authors')

def author_info(request, id):
    context = {
        'author': Author.objects.get(id = id),
        'books': Author.objects.get(id = id).books_written.all(),
        'all_books': Book.objects.all(),
    }
    return render(request, "author_info.html", context)

def append_book(request, id):
    option = Book.objects.get(id = request.POST['select_book'])
    Author.objects.get(id = id).books_written.add(option)
    return redirect(f'/author_info/{id}')





from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('add_book', views.add_book),
    path('book_info/<int:id>', views.book_info),
    path('book_info/<int:id>/append_authors', views.append_authors),
    path('authors', views.authors),
    path('add_author', views.add_author),
    path('author_info/<int:id>', views.author_info),
    path('author_info/<int:id>/append_books', views.append_book),
]